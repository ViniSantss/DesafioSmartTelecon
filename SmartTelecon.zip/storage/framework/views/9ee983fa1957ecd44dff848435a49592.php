<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet" />

</head>
<body>

    <nav class="navbar navbar-expand-lg" style="background-color: #e3f2fd;">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Smart Telecon</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarScroll">
            <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(Route('inicio')); ?>">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(Route('dashboard.home')); ?>">Dashboard</a>
              </li>
            </ul>
              <ul class="nav justify-content-end">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('logout.destroy')); ?>">Loggout</a><p><?php echo e(Auth::user()->NomeProvedor); ?></p>
                </li>
                      <a class="navbar-brand" href="#">
                        <img src="<?php echo e(asset('profile.png')); ?>" alt="Bootstrap" width="30" height="30">
                      </a>
              </ul>
          </div>
        </div>
      </nav>
      <div class="infors col-4">
        <form method="POST" action="<?php echo e(route('dashboard.createDone')); ?>">
            <?php echo csrf_field(); ?>
             <div class="form-group">
                <label>Nome do plano:</label>
                <input type="text" class="form-control" placeholder="Nome" name="name">
             </div>
             <div class="form-group">
               <label>Preço:</label>
               <input type="number" class="form-control" placeholder="Preço" name="price">
            </div>
            <div class="form-group">
               <label>Breve resumo:</label>
               <input type="text" class="form-control" placeholder="Descrição" name="desc">
            </div>
             <button type="submit" class="btn btn-success">Registro</button>
             <?php if($errors->any()): ?>
             <div class="erro">

                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <p><?php echo e($erro); ?></p>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
         <?php endif; ?>
          </form>
       </div>
    </div>
 </div>

</div>
</body>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</html>
<?php /**PATH /home/infor24/Área de Trabalho/Laravel/SmartTelecon/SmartTelecon/resources/views/dashboard/create.blade.php ENDPATH**/ ?>