<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    
    <div class="sidenav" style=" background-repeat: no-repeat; background-size: cover;background-image: url('<?php echo e(asset('assets/engenheiro.png')); ?>')">
             <div class="login-main-text">
                <h2>Smart Telecon<br> Cadrasto</h2>
                <p>Insira seus dados para continuar.</p>
             </div>
          </div>
          <div class="main">
             <div class="col-md-6 col-sm-12">
                <div class="login-form">
                   <form method="POST" action="<?php echo e(route('cadastro')); ?>">
                     <?php echo csrf_field(); ?>
                      <div class="form-group">
                         <label>User Name</label>
                         <input type="text" class="form-control" placeholder="User Name" name="name">
                      </div>
                      <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" placeholder="Email" name="email">
                     </div>
                     <div class="form-group">
                        <label>Cnpj</label>
                        <input type="text" class="form-control" placeholder="000.000.000-00" name="cnpj">
                     </div>
                     <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" placeholder="Password" name="password">
                     </div>
                      <button type="submit" class="btn btn-black">Registro</button>
                      <a href="<?php echo e(Route('login')); ?>" class="btn btn-secondary">Login</a>
                      <?php if($errors->any()): ?>
                      <div class="erro">
       
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <p><?php echo e($erro); ?></p>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  <?php endif; ?>
                   </form>
                </div>
             </div>
          </div>


</body>
</html><?php /**PATH /home/infor24/Área de Trabalho/Laravel/SmartTelecon/SmartTelecon/resources/views/Register.blade.php ENDPATH**/ ?>