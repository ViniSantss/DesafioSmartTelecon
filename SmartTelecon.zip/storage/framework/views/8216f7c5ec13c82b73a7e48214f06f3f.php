<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet" />

</head>
<body>

    <nav class="navbar navbar-expand-lg" style="background-color: #e3f2fd;">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Smart Telecon</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarScroll">
            <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(Route('inicio')); ?>">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(Route('dashboard.home')); ?>">Dashboard</a>
              </li>
            </ul>
              <ul class="nav justify-content-end">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="<?php echo e(route('logout.destroy')); ?>">Loggout</a><p><?php echo e(Auth::user()->NomeProvedor); ?></p>
                </li>
                      <a class="navbar-brand" href="#">
                        <img src="<?php echo e(asset('profile.png')); ?>" alt="Bootstrap" width="30" height="30">
                      </a>
              </ul>
          </div>
        </div>
      </nav>
      <div class="infors">
    <h1 class="mt-4">Seja bem vindo <?php echo e(Auth::user()->NomeProvedor); ?></h1>
    <?php if($errors->any()): ?>
                      <div class="erro">
       
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <p><?php echo e($erro); ?></p>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  <?php endif; ?>
    


    <h3>Seus Planos</h3>
    <div class="container" style="margin: 0">
        <table>
            <thead>
                <tr>
                    <th>Plano</th>
                    <th>Criador</th>
                    <th>Preço</th>
                    <th>Descrição</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($planos->NomePlano); ?></td>
                        <td><?php echo e($planos->DonoPlano); ?> </td>
                        <td><?php echo e($planos->PrecoPlano); ?>R$ </td>
                        <td><?php echo e($planos->DescPlano); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<br>

    <a class="btn btn-success" href="<?php echo e(Route('dashboard.create')); ?>">Criar novo Plano</a>




    <?php if(Auth::user()->Classe == 'Admin'): ?>

<h3>Provedores Cadastrados</h3>
        <div class="container" style="margin: 0">
            <table>
                <thead>
                    <tr>
                        <th>Nomes</th>
                        <th>Tipo</th>
                        <th>Email</th>
                        <th>CNPJ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $provedors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($usuario->NomeProvedor); ?></td>
                            <td><?php echo e($usuario->Classe); ?> </td>
                            <td><?php echo e($usuario->EmailProvedor); ?> </td>
                            <td><?php echo e($usuario->CnpjProvedor); ?> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>




<?php else: ?>
<br>
<h4>Esse usuario não é um administrador</h4>
<p>Para testar, aperte esse botão para ganhar a classe administrador</p>
<a class="btn btn-success" href="<?php echo e(Route('dashboard.getadmin')); ?>">admin</a>

<?php endif; ?>

</div>
</body>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</html>
<?php /**PATH /home/infor24/Área de Trabalho/Laravel/SmartTelecon/SmartTelecon/resources/views/dashboard/dashboard.blade.php ENDPATH**/ ?>